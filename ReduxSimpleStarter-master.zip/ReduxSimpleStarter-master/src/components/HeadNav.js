import React, { Component } from 'react';
import { Container, Col, Form, FormGroup, Label, Input, Button, Jumbotron} from 'reactstrap';
class HeadNav extends React.Component {
  handleSelect(eventKey, event) {
    event.preventDefault();
    alert(`selected ${eventKey}`);
  }
  function handleSelect(selectedKey) {
  alert(`selected ${selectedKey}`);
}

const navInstance = (
  <Nav bsStyle="pills" activeKey={1} onSelect={handleSelect}>
    <NavItem eventKey={1} href="/home">
      NavItem 1 content
    </NavItem>
    <NavItem eventKey={2} title="Item">
      NavItem 2 content
    </NavItem>
    <NavItem eventKey={3} disabled>
      NavItem 3 content
    </NavItem>
  </Nav>
);


  render() {
    return (
      <div className="container">
      <Jumbotron>
        <h1>Way Back Machine</h1>
        <p>A decentralized place for all our internet archives</p>
      <Button bsStyle="primary">Learn more</Button>
      </Jumbotron>;

  </div>
    );
  }
}
