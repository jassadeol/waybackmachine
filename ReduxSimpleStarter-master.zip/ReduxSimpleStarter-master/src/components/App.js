import React, { Component } from 'react';
import { Button } from 'reactstrap';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
const axios = require('axios');

import Search from './Search';
import SnapshotList from './SnapshotList';
import HeadNav0 from './HeadNav0';

export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchUrl: '',
      entries: [],
      siteViewingId: '',
    }
  }

  setUrl(url) {
    //console.log('setting', url);
    this.setState({
      searchUrl: url,
    });
  }

  setEntries(ent) {
    this.setState({entries: ent});
  }

  setViewId (id)
  {
    this.setState({siteViewingId: id});
  }

  renderPage() {
    if (this.state.siteViewingId) {
      return <ViewUrl url={this.state.searchUrl} /> //this.state.siteViewingId=false  iframe
    } else if (this.state.searchUrl) { //
      return <SnapshotList url={this.state.searchUrl} entries={this.state.entries} />
    } else {
      return <Search setUrl={url => this.setUrl(url)} />
    }
  }

  render() {

    const pageToRender = this.renderPage();
    return (
      <div>

        {pageToRender}
        <HeadNav0/>

      </div>
    );
  }
}
