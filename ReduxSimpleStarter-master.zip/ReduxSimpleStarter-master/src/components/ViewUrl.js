import React, { Component } from 'react';


export default class Search extends Component {
  constructor(props)
  {
    this.state = {url:''}
  }
  return (
    <iframe url='this.state.url' width="450px" height="450px"> </iframe>
    )
}
