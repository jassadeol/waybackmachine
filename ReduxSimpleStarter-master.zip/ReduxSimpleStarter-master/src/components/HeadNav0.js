import React, { Component } from 'react';
export default class HeadNav0 extends React.Component {
  handleSelect(eventKey, event) {
    event.preventDefault();
    alert(`selected ${eventKey}`);
  }

  render() {
    return (
    <div className="container">
    <div className="jumbotron" >
        <h1>Way Back Machine</h1>
          <p> A decentralized place for all our internet archives</p>
    </div>
    <a className="navbar-brand">
      <img src="../images/logo.png" width="75px"/>
    </a>
    <div className="collapse navbar-collapse" id="collapse_target"> </div>
    <nav className="navbar navbar-expand-md navbar-dark bg-dark sticky-top ">
      <span className="navbar-text">
      </span>
      <ul className="navbar-nav">
        <li className="nav-item">
          <a className="nav-link" href="#">Home</a>
        </li>
        <li className="nav-item">
          <a className="nav-link" href="#">About Us</a>
        </li>
        <li className="nav-item">
          <a className="nav-link" href="#">Explore</a>
        </li>
        <li className="nav-item">
          <a className="nav-link" href="#">Contact</a>
        </li>
      </ul>
  </nav>
  </div>
    );
  }
}
